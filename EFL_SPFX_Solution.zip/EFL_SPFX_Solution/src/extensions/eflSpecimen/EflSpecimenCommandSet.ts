import CustomPanel, { ICustomPanelProps } from  "../../components/CustomPanel"
import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'EflSpecimenCommandSetStrings';
import * as React from 'react'; 
import * as ReactDom from 'react-dom';
import { sp } from "@pnp/sp"; 
import { assign } from '@uifabric/utilities';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IEflSpecimenCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  //sampleTextTwo: string;
}

const LOG_SOURCE: string = 'EflSpecimenCommandSet';

export default class EflSpecimenCommandSet extends BaseListViewCommandSet<IEflSpecimenCommandSetProperties> {

  // @override
  // public onInit(): Promise<void> {
  //   Log.info(LOG_SOURCE, 'Initialized EflSpecimenCommandSet');
  //   return Promise.resolve();
  // }
  // private _showPanel(itemId: number, currentTitle: string) {    
  //    this._renderPanelComponent({        
  //      isOpen: true,       
  //      currentTitle,       
  //      itemId,       
  //      listId: this.context.pageContext.list.id.toString(),      
  //        onClose: this._dismissPanel   
  //    });  
  //  }

  private _showPanel(itemId: any,itemFormNo: any, itemFormTitle: any) {    
    this._renderPanelComponent({        
      isOpen: true,       
      //currentTitle,       
      itemId,
      itemFormNo,    
      itemFormTitle,   
      listId: this.context.pageContext.list.id.toString(),      
        onClose: this._dismissPanel   
    });  
  }

   private _dismissPanel() {      
     this._renderPanelComponent({ isOpen: false }); 
  }
  
  private _renderPanelComponent(props: any) {     
    const element: React.ReactElement<ICustomPanelProps> = React.createElement(CustomPanel, assign({        
      onClose: null,
      context:this.context,       
      currentTitle: null,    
      itemId: null,  
      itemFormNo: null,
      itemFormTitle: null,
      isOpen: false,      
      listId: null      
    }, props));     
    ReactDom.render(element, this.panelPlaceHolder);  
   }  

  private panelPlaceHolder: HTMLDivElement = null;
  @override   public onInit(): Promise<void> {      
    Log.info(LOG_SOURCE, 'Initialized CommandSetWithPanelCommandSet');      
    // // Setup the PnP JS with SPFx context      
    // sp.setup({       
    //   spfxContext: this.context      
    // });  
    // // Create the container for our React component     
    this.panelPlaceHolder = document.body.appendChild(document.createElement("div"));   
    let newbutton: any = document.getElementsByName("New")[0] || document.documentElement;  
    newbutton.style.display = "none"; 
    let EdidGridView: any = document.getElementsByName("Edit in grid view")[0] || document.documentElement; 
    EdidGridView.style.display = "none"; 
    let Share: any = document.getElementsByName("Share")[0] || document.documentElement; 
    Share.style.display = "none"; 
    let PowerApps: any = document.getElementsByName("Power Apps")[0] || document.documentElement; 
    PowerApps.style.display = "none"; 
    let Automate: any = document.getElementsByName("Automate")[0] || document.documentElement; 
    Automate.style.display = "none"; 
   //let AlertMe: any = document.getElementsByName("Alert me")[0] || document.documentElement; 
   //AlertMe.style.display = "none"; 
   //let ManageAlerts: any = document.getElementsByName("Manage my alerts")[0] || document.documentElement;
   //ManageAlerts.style.display = "none";  
   
   
   //Copy link
   //Comment
   //Delete
    
    
     return Promise.resolve();    
    }

  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {
    var Libraryurl = this.context.pageContext.list.title;  
    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');
    if (compareOneCommand) {
      // This command should be hidden unless exactly one row is selected.
      compareOneCommand.visible = (event.selectedRows.length >= 1 && Libraryurl == "Environmental Form Library" );
      let Edit1: any = document.getElementsByName("Edit")[0] || document.documentElement; 
      Edit1.style.display = "none"; 
      let newbutton1 = document.getElementsByName("New")[0]; 
    newbutton1.style.display = "none"; 
      
    }
  }

  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void {
    switch (event.itemId) {
      case 'COMMAND_1':
        // let selectedItem = event.selectedRows[0];   
        let listItemId=[];
        let itemFormNo=[];
        let itemFormTitle=[];
        let selectedItem = event.selectedRows.forEach(e => {
          listItemId.push(e.getValueByName('ID'));
          itemFormNo.push(e.getValueByName('FormNumber'));
          itemFormTitle.push(e.getValueByName('FormTitle'));
        });                 
        //selectedItem.getValueByName('ID') as number;          
        //const title = selectedItem.getValueByName("Title");         
         this._showPanel(listItemId,itemFormNo,itemFormTitle);         
         break;      
         
      // case 'COMMAND_2':
      //   Dialog.alert(`${this.properties.sampleTextTwo}`);
      //   break;
      default:
        throw new Error('Unknown command');
    }
  }
}
