declare interface IEflSpecimenCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'EflSpecimenCommandSetStrings' {
  const strings: IEflSpecimenCommandSetStrings;
  export = strings;
}
