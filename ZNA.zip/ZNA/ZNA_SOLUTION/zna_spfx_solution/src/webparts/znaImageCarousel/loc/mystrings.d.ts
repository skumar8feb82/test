declare interface IZnaImageCarouselWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ZnaImageCarouselWebPartStrings' {
  const strings: IZnaImageCarouselWebPartStrings;
  export = strings;
}
