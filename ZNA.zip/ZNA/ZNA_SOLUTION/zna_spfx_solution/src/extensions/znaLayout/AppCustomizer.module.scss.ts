/* tslint:disable */
require("./AppCustomizer.module.css");
const styles = {
  app: 'app_2aa20577',
  top: 'top_2aa20577',
  bottom: 'bottom_2aa20577'
};

export default styles;
/* tslint:enable */