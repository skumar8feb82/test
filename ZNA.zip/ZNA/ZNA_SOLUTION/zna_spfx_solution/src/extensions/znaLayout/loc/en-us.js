define([], function() {
  return {
    "Title": "ZnaLayoutApplicationCustomizer"
  }
});