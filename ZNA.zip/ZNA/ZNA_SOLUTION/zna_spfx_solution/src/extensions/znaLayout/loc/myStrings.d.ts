declare interface IZnaLayoutApplicationCustomizerStrings {
  Title: string;
}

declare module 'ZnaLayoutApplicationCustomizerStrings' {
  const strings: IZnaLayoutApplicationCustomizerStrings;
  export = strings;
}
