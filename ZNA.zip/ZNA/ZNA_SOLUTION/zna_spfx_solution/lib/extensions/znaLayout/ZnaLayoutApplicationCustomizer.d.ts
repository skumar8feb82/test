import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
export interface IZnaLayoutApplicationCustomizerProperties {
    Top: string;
    Bottom: string;
    Logo: string;
    favicon: string;
}
/** A Custom Action which can be run during execution of a Client Side Application */
export default class ZnaLayoutApplicationCustomizer extends BaseApplicationCustomizer<IZnaLayoutApplicationCustomizerProperties> {
    private _topPlaceholder;
    private _bottomPlaceholder;
    private _onDispose;
    onInit(): Promise<void>;
    private _renderPlaceHolders;
}
//# sourceMappingURL=ZnaLayoutApplicationCustomizer.d.ts.map