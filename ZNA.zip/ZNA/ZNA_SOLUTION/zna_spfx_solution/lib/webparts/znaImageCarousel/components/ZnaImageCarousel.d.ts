import * as React from 'react';
import { IZnaImageCarouselProps } from './IZnaImageCarouselProps';
export default class ZnaImageCarousel extends React.Component<IZnaImageCarouselProps, {}> {
    render(): React.ReactElement<IZnaImageCarouselProps>;
}
//# sourceMappingURL=ZnaImageCarousel.d.ts.map